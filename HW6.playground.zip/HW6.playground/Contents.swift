import UIKit

var array = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]


struct Queue<T> {
    
    enum queue<T> {
        case start
        case stop
        case moveUp
        case moveDown
    }
    
    let string = array.filter { (n) -> Bool in
        if n == 5 {
            return true
        } else {
            return false
        }
    }
    
    mutating func newElement<T: BinaryInteger>(item: T) {
        for (index, value) in array.enumerated() {
            if item == value {
                array.remove(at: index)
            }
        }
    }
    
    var val: T?
    
    subscript<T: BinaryInteger>(ind: T) -> T? {
        mutating get {
            for (index, _) in array.enumerated() {
                if index != ind {
                    val = nil
                } else {
                    return val as! T?
                }
            }
            return val as! T?
        }
    }
}
var q = Queue<Int>()
q.newElement(item: 3)
print(q.string)
print(array)
print(q[3] ?? 0)

